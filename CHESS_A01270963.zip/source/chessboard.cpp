#include "chessboard.hpp"

Chessboard::Chessboard() {
    chessborder = 0;
    chessboard = 0;
    YT = -1.0;
    OB =  5.0;
    IB =  4.0;
    T = (YT - 0.75);
    
}

void Chessboard::display() {
    GLfloat x, z;
    GLfloat specular[] = { 0.1, 0.1, 0.1, 1.0 };
    GLfloat brown[]    = { 0.857, 0.147, 0.000, 1.0 };
    GLfloat white[]    = { 1, 1, 1, 1.0 };
    GLfloat black[]     = { 0, 0, 0, 1.0 };
    int i, name;
    chessborder = glGenLists(1);
    glNewList(chessborder, GL_COMPILE);
    {
        glMaterialfv(GL_FRONT, GL_DIFFUSE, brown);
        glMaterialfv(GL_FRONT, GL_AMBIENT, brown);
        glMaterialfv(GL_FRONT, GL_SPECULAR, specular);
        glMaterialf(GL_FRONT, GL_SHININESS, 10.0);
        glBegin(GL_QUADS);
        {
            /* back */
            glNormal3f(0.0, 1.0, 0.0);
            glVertex3f(-OB, YT, -OB);
            glNormal3f(0.0, 1.0, 0.0);
            glVertex3f(-IB, YT, -IB);
            glNormal3f(0.0, 1.0, 0.0);
            glVertex3f( IB, YT, -IB);
            glNormal3f(0.0, 1.0, 0.0);
            glVertex3f( OB, YT, -OB);
            
            /* right */
            glNormal3f(0.0, 1.0, 0.0);
            glVertex3f( OB, YT, -OB);
            glNormal3f(0.0, 1.0, 0.0);
            glVertex3f( IB, YT, -IB);
            glNormal3f(0.0, 1.0, 0.0);
            glVertex3f( IB, YT,  IB);
            glNormal3f(0.0, 1.0, 0.0);
            glVertex3f( OB, YT,  OB);
            
            /* front */
            glNormal3f(0.0, 1.0, 0.0);
            glVertex3f( OB, YT,  OB);
            glNormal3f(0.0, 1.0, 0.0);
            glVertex3f( IB, YT,  IB);
            glNormal3f(0.0, 1.0, 0.0);
            glVertex3f(-IB, YT,  IB);
            glNormal3f(0.0, 1.0, 0.0);
            glVertex3f(-OB, YT,  OB);
            
            /* left */
            glNormal3f(0.0, 1.0, 0.0);
            glVertex3f(-OB, YT,  OB);
            glNormal3f(0.0, 1.0, 0.0);
            glVertex3f(-IB, YT,  IB);
            glNormal3f(0.0, 1.0, 0.0);
            glVertex3f(-IB, YT, -IB);
            glNormal3f(0.0, 1.0, 0.0);
            glVertex3f(-OB, YT, -OB);
        } glEnd();
        
        glBegin(GL_QUADS);
        {
            /* back */
            glNormal3f(0.0, 0.0, -1.0);
            glVertex3f(-OB, T, -OB);
            glNormal3f(0.0, 0.0, -1.0);
            glVertex3f(-OB, YT, -OB);
            glNormal3f(0.0, 0.0, -1.0);
            glVertex3f( OB, YT, -OB);
            glNormal3f(0.0, 0.0, -1.0);
            glVertex3f( OB, T, -OB);
            
            /* right */
            glNormal3f(1.0, 0.0, 0.0);
            glVertex3f( OB, T, -OB);
            glNormal3f(1.0, 0.0, 0.0);
            glVertex3f( OB, YT, -OB);
            glNormal3f(1.0, 0.0, 0.0);
            glVertex3f( OB, YT,  OB);
            glNormal3f(1.0, 0.0, 0.0);
            glVertex3f( OB, T,  OB);
            
            /* front */
            glNormal3f(0.0, 0.0, 1.0);
            glVertex3f( OB, T,  OB);
            glNormal3f(0.0, 0.0, 1.0);
            glVertex3f( OB, YT,  OB);
            glNormal3f(0.0, 0.0, 1.0);
            glVertex3f(-OB, YT,  OB);
            glNormal3f(0.0, 0.0, 1.0);
            glVertex3f(-OB, T,  OB);
            
            /* left */
            glNormal3f(-1.0, 0.0, 0.0);
            glVertex3f(-OB, T,  OB);
            glNormal3f(-1.0, 0.0, 0.0);
            glVertex3f(-OB, YT,  OB);
            glNormal3f(-1.0, 0.0, 0.0);
            glVertex3f(-OB, YT, -OB);
            glNormal3f(-1.0, 0.0, 0.0);
            glVertex3f(-OB, T, -OB);
        } glEnd();
    }
    glEndList();
    chessboard = glGenLists(1);
    glNewList(chessboard, GL_COMPILE);
    {
        glMaterialfv(GL_FRONT, GL_DIFFUSE, white);
        glMaterialfv(GL_FRONT, GL_AMBIENT, white);
        glMaterialfv(GL_FRONT, GL_SPECULAR, specular);
        glMaterialf(GL_FRONT, GL_SHININESS, 10.0);
        
        i = name = 0;
        for(x = -4.0; x < 4.0; x += 1.0)
        {
            for(z = -4.0; z < 4.0; z += 1.0)
            {
                i++;
                if(i % 2)
                {
                    glLoadName(name++);
                    glBegin(GL_QUADS);
                    {
                        glNormal3f(0.0, 1.0, 0.0);
                        glVertex3f(x, YT, z);
                        glNormal3f(0.0, 1.0, 0.0);
                        glVertex3f(x, YT, z + 1.0);
                        glNormal3f(0.0, 1.0, 0.0);
                        glVertex3f(x + 1.0, YT, z + 1.0);
                        glNormal3f(0.0, 1.0, 0.0);
                        glVertex3f(x + 1.0, YT, z);
                    } glEnd();
                }
            }
            i++;
        }
        i = 1;
        
        glMaterialfv(GL_FRONT, GL_DIFFUSE, black);
        glMaterialfv(GL_FRONT, GL_AMBIENT, black);
        glMaterialfv(GL_FRONT, GL_SPECULAR, specular);
        glMaterialf(GL_FRONT, GL_SHININESS, 10.0);
        
        for(x = -4.0; x < 4.0; x += 1.0)
        {
            for(z = -4.0; z < 4.0; z += 1.0)
            {
                i++;
                if(i % 2)
                {
                    glLoadName(name++);
                    glBegin(GL_QUADS);
                    {
                        glNormal3f(0.0, 1.0, 0.0);
                        glVertex3f(x, YT, z);
                        glNormal3f(0.0, 1.0, 0.0);
                        glVertex3f(x, YT, z + 1.0);
                        glNormal3f(0.0, 1.0, 0.0);
                        glVertex3f(x + 1.0, YT, z + 1.0);
                        glNormal3f(0.0, 1.0, 0.0);
                        glVertex3f(x + 1.0, YT, z);
                    } glEnd();
                }
            }
            i++;
        }
        
    } glEndList();
}

void Chessboard::idle() {
    glPushMatrix();
    {
        glCallList(chessborder);
        glCallList(chessboard);
    } glPopMatrix();
glTranslatef(-IB + 0.5, YT, IB - 0.5);
}
