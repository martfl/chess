//
//  chessgame.cpp
//  chess
//
//  Created by Martín Fernández on 10/26/17.
//  Copyright © 2017 Martín Fernández. All rights reserved.
//

#include "chessgame.hpp"

Game::Game(){
    chess = new Chessboard();
    pieces[1] = new Chesspiece("assets/king.obj");
    pieces[2] = new Chesspiece("assets/queen.obj");
    pieces[3] = new Chesspiece("assets/bishop.obj");
    pieces[4] = new Chesspiece("assets/knight.obj");
    pieces[5] = new Chesspiece("assets/rook.obj");
    pieces[6] = new Chesspiece("assets/pawn.obj");
}

void Game::get_objects() {
    chess->display();
    
    for(int i = 1; i <= 6; i++)
    {
        pieces[i]->display();
    }
}

void Game::render() {
    static Piece piece = (Piece) 0, signed_piece, moving_piece = (Piece) 0;
    GLboolean moving = GL_FALSE;
    static float start_x, start_y, end_x, end_y;
    GLfloat light_position0[] = {  1.0, 1.0, 1.0, 0.0 };
    
    if(Start_Moving && Old_Mouse_Y != -1 && Old_Mouse_X != -1)
    {
        moving_piece = board[Old_Mouse_Y][Old_Mouse_X];
        board[Old_Mouse_Y][Old_Mouse_X] = NONE;
        
        start_x = Old_Mouse_X;
        start_y = Old_Mouse_Y;
        end_x = Move_Mouse_X;
        end_y = Move_Mouse_Y;
        
        moving = GL_TRUE;
        Start_Moving = GL_FALSE;
    }
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    
    
    glPushMatrix();
    {
        glLightfv(GL_LIGHT0, GL_POSITION, light_position0);
        glTranslatef(0.0, 0.0, Z_Trans);
        glRotatef(X_Rot, 1.0, 0.0, 0.0);
        glRotatef(Spin, 0.0, 1.0, 0.0);
        
        chess->idle();
        
        glPushMatrix();
        {
            if(Grabbing)
            {
                glLineWidth(4.0);
            
                if(Grabbing && Old_Mouse_X != -1)
                {
                    /* draws yellow square on selection */
                    set_material(Yellow);
                    glPushMatrix();
                    {
                        glTranslatef((float)Old_Mouse_X, 0.01, (float)-Old_Mouse_Y);
                        glBegin(GL_LINE_LOOP);
                        {
                            glVertex3f(-0.5, 0.0, -0.5);
                            glVertex3f(-0.5, 0.0,  0.5);
                            glVertex3f( 0.5, 0.0,  0.5);
                            glVertex3f( 0.5, 0.0, -0.5);
                        } glEnd();
                        
                    } glPopMatrix();
                }
                
                /* draws red square on selection depending on mouse */
                set_material(Red);
                
                glTranslatef((float)Mouse_X, 0.01, (float)-Mouse_Y);
                
                glBegin(GL_LINE_LOOP);
                {
                    glVertex3f(-0.5, 0.0, -0.5);
                    glVertex3f(-0.5, 0.0,  0.5);
                    glVertex3f( 0.5, 0.0,  0.5);
                    glVertex3f( 0.5, 0.0, -0.5);
                } glEnd();
                
                glLineWidth(1.0);
            }
        } glPopMatrix();
        
        //MOVES PIECE TO NEW COORDINATES
        glPushMatrix();
        {
            board[Move_Mouse_Y][Move_Mouse_X] = moving_piece;
            if(moving)
            {
                
                if(moving_piece < 0)  /* piece is black  */
                {
                    set_material(Black);
                }
                else  /* piece is white */
                {
                    set_material(White);
                }
                piece = moving_piece < 0 ? (Piece)-moving_piece : moving_piece;
                
                glTranslatef(end_x,pieces[piece]->height,-end_y);
                
                if(moving_piece == KNIGHT)
                    glRotatef(180.0, 0.0, 1.0, 0.0);
                glCallList(pieces[piece]->dlist);
            }
            
        } glPopMatrix();
        
        //LOOP THROUGH BOARD AND RENDER EACH PIECE
        glPushMatrix();
        {
            for(int i = 0; i < 8; i++)
            {
                for(int j = 0; j < 8; j++)
                {
                    glPushMatrix();
                    {
                        if (board[i][j] != 0)
                        {
                            signed_piece = board[i][j];
                            piece = signed_piece < 0 ? (Piece)-signed_piece
                            : signed_piece;
                            
                            if(signed_piece < 0)  /* piece is black */
                            {
                                set_material(Black);
                            }
                            else  /* piece is white */
                            {
                                set_material(White);
                            }
                            
                            glTranslatef(j, pieces[piece]->height, -i);
                            
                            if(signed_piece == KNIGHT)
                                glRotatef(180.0, 0.0, 1.0, 0.0);
                            
                            glCallList(pieces[piece]->dlist);
                        }
                    } glPopMatrix();
                }
            }
        } glPopMatrix();
    } glPopMatrix();
    glutSwapBuffers();
}

void Game::move(unsigned char key) {
    switch(key)
    {
        case 27:                /* esc to exit */
            exit(1);
            break;
            
        case 'Z':                /* zoom in */
            Z_Trans += 0.25;
            break;
            
        case 'z':                /* zoom out */
            Z_Trans -= 0.25;
            break;
            
        case 'X':                /* up */
            X_Rot -= 2.0;
            break;
            
        case 'x':                /* down */
            X_Rot += 2.0;
            break;
        default:
            break;
    }
    glutPostRedisplay();
}


