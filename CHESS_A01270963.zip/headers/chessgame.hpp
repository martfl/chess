#ifdef __APPLE__
#include <GLUT/glut.h>
#include <OpenGL/gl.h>
#include <OpenGL/glu.h>
#else
#include "freeglut.h"
#endif

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <stdarg.h>

#include "typedefs.h"
#include "chessboard.hpp"
#include "chesspiece.hpp"

extern GLboolean Start_Moving, Grabbing;
extern GLint Old_Mouse_X, Old_Mouse_Y, Move_Mouse_X, Move_Mouse_Y, Mouse_X, Mouse_Y;
extern GLfloat X_Rot, Z_Trans, Spin;
class Game {
public:
    Game();
    
    class Chessboard  *chess;
    Chesspiece *pieces[7];

    void render();
    void get_objects();
    void move(unsigned char key);
    
};
