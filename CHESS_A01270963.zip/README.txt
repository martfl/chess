README


CHESS GAME
BY 
Martín Alberto Fernández Lorenzo
A01270963

GAMEPLAY IS NOT YET IMPLEMENTED

PIECES MAY MOVE FREELY THROUGH BOARD
REGARDLESS OF CHESS RULES


CONTROLS:

Z - Zooms in
z - Zooms out

X - Moves up
x - Moves down

Esc - Quits

Moving a piece requires clicking on it and moving to the new square while holding.
A red square should appear on the destination square and a yellow one on the original square.



KNOWN BUGS

Clicking on an empty square causes a crash
Trying to move a piece outside the board may cause a crash (not always)