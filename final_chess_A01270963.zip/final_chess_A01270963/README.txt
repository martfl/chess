README


CHESS GAME
BY 
Martín Alberto Fernández Lorenzo
A01270963

GAMEPLAY IS NOT FULLY IMPLEMENTED

Moves are validated. No end-game is provided. On checkmate game should be restarted.


CONTROLS:

Z - Zooms in
z - Zooms out

X - Moves up
x - Moves down

Esc - Quits

Moving a piece requires clicking on it and moving to the new square while holding.
A red square should appear on the destination square and a yellow one on the original square.


KNOWN BUGS

Turns may not work allowing the opposite side to move twice.
